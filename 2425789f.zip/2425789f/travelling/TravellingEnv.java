import jason.asSyntax.*;
import jason.environment.Environment;
import jason.environment.grid.GridWorldModel;
import jason.environment.grid.GridWorldView;
import jason.environment.grid.Location;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.logging.Logger;

import java.util.ArrayList;
import java.util.Arrays;



public class TravellingEnv extends Environment {

    public static final int GSize = 10; // grid size
	public static final int CITY  = 8; 

	
	public static final Literal c = Literal.parseLiteral("close");
	public static final Term    cp = Literal.parseLiteral("compare(permutation)");
	public static final Term    su = Literal.parseLiteral("set_up");
	
    static Logger logger = Logger.getLogger(TravellingEnv.class.getName());

    private TravellingModel model;
    private TravellingView  view;

    @Override
    public void init(String[] args) {
        model = new TravellingModel();
        view  = new TravellingView(model);
        model.setView(view);
        updatePercepts();
	}

    @Override
    public boolean executeAction(String ag, Structure action) {
        logger.info(ag+" doing: "+ action);
		
        try {
			if (action.equals(su)){
				model.setUp();
			}
			else if (action.equals(cp)){
				model.comparePermutation();
			}
			
             else if (action.getFunctor().equals("go_to")) {
                int x = (int)((NumberTerm)action.getTerm(0)).solve();
                int y = (int)((NumberTerm)action.getTerm(1)).solve();
				model.goTo(x,y);
			}
			else {
               return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        updatePercepts();

        try {
            Thread.sleep(200);
        } catch (Exception e) {}
        informAgsEnvironmentChanged();
        return true;
    }

    /** creates the agents perception based on the TravellingModel */
    void updatePercepts() {
        clearPercepts();
		
        Location cl = model.getAgPos(0);
		
		Literal currentLocation= Literal.parseLiteral("current_location(" + cl.x + "," + cl.y + ")");
		addPercept(currentLocation);
		
		if(TravellingModel.start == true){
			
			Literal c = Literal.parseLiteral("city(5,5,unavailable)");
			addPercept(c);
			c = Literal.parseLiteral("city(2,6,available)");
			addPercept(c);
			c = Literal.parseLiteral("city(3,9,available)");
			addPercept(c);
			c = Literal.parseLiteral("city(7,2,available)");
			addPercept(c);
			
			
			TravellingModel.start = false;
		}
		
    }
	
	

    class TravellingModel extends GridWorldModel {
		
		static boolean start = false;
		
        private TravellingModel() {
            super(10, 10, 50);
			
				Location hostLoc = new Location(5, 5);
                setAgPos(0, hostLoc);

			add(CITY, hostLoc);
			add(CITY, 2,6);
			add(CITY, 3,9);
			add(CITY, 7,2);
			
        }
		
		void setUp(){
			start = true;
		}
		void goTo(int x , int y){
			Location t = getAgPos(0); //traveller
			
            if (t.x < x)      t.x++;
            else if (t.x > x) t.x--;
            if (t.y < y)      t.y++;
            else if (t.y > y) t.y--;
			
            setAgPos(0, t);
		}
		
		void comparePermutation(){
		
		}
		
		
	
    }

    class TravellingView extends GridWorldView {

        public TravellingView(TravellingModel model) {
            super(model, "Travelling World", 600);
            defaultFont = new Font("Arial", Font.BOLD, 18); // change default font
            setVisible(true);
            repaint();
        }

        /** draw application objects */
        @Override
        public void draw(Graphics g, int x, int y, int object) {
            switch (object) {
            case TravellingEnv.CITY:
                drawCITY(g, x, y);
                break;

            }
			
			
        }

        @Override
        public void drawAgent(Graphics g, int x, int y, Color c, int id) {
            String label = "Salesman";
            c = Color.blue;
            super.drawAgent(g, x, y, c, -1);
               g.setColor(Color.black);

            super.drawString(g, x, y, defaultFont, label);
            repaint();
        }

        public void drawCITY(Graphics g, int x, int y) {
            super.drawObstacle(g, x, y);
            g.setColor(Color.green);
			String city = "c(" + x + "," + y + ")";
            drawString(g, x, y, defaultFont, city);
        }
		

    }
}
