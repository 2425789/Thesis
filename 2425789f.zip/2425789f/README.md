Installation of software is provided by http://jason.sourceforge.net/mini-tutorial/getting-started/
After installing the jason/jedit software, simply run the project