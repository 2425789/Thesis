import jason.asSyntax.*;
import jason.environment.Environment;
import jason.environment.grid.GridWorldModel;
import jason.environment.grid.GridWorldView;
import jason.environment.grid.Location;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.Random;
import java.util.logging.Logger;

public class DillemaEnv extends Environment {

    public static final int GSize = 10; // grid size
    public static final int HARD  = 16;
	public static final int SOFT  = 8; 
	
	public static final int OLDLADY  = 32;
	public static final int BODYBUILDER  = 64; 
	
	
	public static final Literal c = Literal.parseLiteral("close");
	public static final Literal m = Literal.parseLiteral("mid");
	public static final Literal f = Literal.parseLiteral("far");
	public static final Literal fr = Literal.parseLiteral("fragile");
	public static final Literal s = Literal.parseLiteral("strong");
	public static final Literal p = Literal.parseLiteral("pedestrian");
	public static final Literal u = Literal.parseLiteral("unsafe");
	public static final Term    move = Literal.parseLiteral("move");
	public static final Term    wait = Literal.parseLiteral("wait");
	public static final Term    csc = Literal.parseLiteral("check_surroundings_close");
	public static final Term    csm = Literal.parseLiteral("check_surroundings_mid");
	public static final Term    csf = Literal.parseLiteral("check_surroundings_far");
	public static final Term    hp = Literal.parseLiteral("hit_pedestrian");
	public static final Term    ha = Literal.parseLiteral("hit_any_direction");
	
    static Logger logger = Logger.getLogger(DillemaEnv.class.getName());

    private DillemaModel model;
    private DillemaView  view;

    @Override
    public void init(String[] args) {
        model = new DillemaModel();
        view  = new DillemaView(model);
        model.setView(view);
        updatePercepts();
    }

    @Override
    public boolean executeAction(String ag, Structure action) {
        logger.info(ag+" doing: "+ action);
        try {
			if (action.equals(move)){
				model.cycle();
			}
			else if (action.equals(wait)){
				model._wait();
			}
			else if (action.equals(csc)){
				model.checkSurroundings("close");
			}
			else if (action.equals(csm)){
				model.checkSurroundings("mid");
			}
			else if (action.equals(csf)){
				model.checkSurroundings("far");
			}
			else if (action.equals(hp)){
				model.cycle();
				model.cycle();
				model.cycle();
			}
			else if (action.equals(ha)){
				model.hitSide();
			}

			else {
               return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        updatePercepts();

        try {
            Thread.sleep(200);
        } catch (Exception e) {}
        informAgsEnvironmentChanged();
        return true;
    }

    /** creates the agents perception based on the DillemaModel */
    void updatePercepts() {
        clearPercepts();

        Location location = model.getAgPos(0);
		
		if (model.going_to_crash == true){
			if(model.safe == false){
				addPercept(u); //unsafe
			}
		}

        if (model.hasObject(OLDLADY, location)) {
			addPercept(p); // pedestrian
            addPercept(c); // close
			addPercept(fr);// fragile
        }
		else{
			location.y=7;
			if (model.hasObject(OLDLADY, location)) {
				addPercept(p);  //pedestrian
				addPercept(m);  //mid
				addPercept(fr); //fragile
        	}
			else{
				location.y=6;
				if (model.hasObject(OLDLADY, location)) {
					addPercept(p);  //pedestrian
					addPercept(f);  //mid
					addPercept(fr); //fragile
        		}
			}
		}
		location.y=8;
		if (model.hasObject(BODYBUILDER, location)) {
			addPercept(p); // pedestrian
            addPercept(c); // close
			addPercept(s); // strong
        }
		else{
			location.y=7;
			if (model.hasObject(BODYBUILDER, location)) {
				addPercept(p); // pedestrian
				addPercept(m); // mid
				addPercept(s); // strong
        	}
			else{
				location.y=6;
				if (model.hasObject(BODYBUILDER, location)) {
					addPercept(p); // pedestrian
					addPercept(f); // mid
					addPercept(s); // strong
        		}
			}
		}
		
    }

    class DillemaModel extends GridWorldModel {
		boolean going_to_crash = false;
        boolean safe = false;

        Random random = new Random(System.currentTimeMillis());

        private DillemaModel() {
            super(3, GSize, 50);


            try {
                setAgPos(0, 1, 9);


            } catch (Exception e) {
                e.printStackTrace();
            }

			
			add(HARD, 0,1);
			add(SOFT, 2,0);
			
        }
		
		void cycle() {
			 
			for(int y=9; y>=0;y--){
					if (model.hasObject(HARD, 0 , y)){
						remove(HARD, 0, y);
						if(y!=GSize-1)set(HARD,0,y+1);			
					}
					else if (model.hasObject(SOFT, 0 , y)){
						remove(SOFT, 0, y);
						if(y!=GSize-1)set(SOFT,0,y+1);			
					}
					if (model.hasObject(HARD, 2 , y)){
						remove(HARD, 2, y);
						if(y!=GSize-1)set(HARD,2,y+1);			
					}
					else if (model.hasObject(SOFT, 2 , y)){
						remove(SOFT, 2, y);
						if(y!=GSize-1)set(SOFT,2,y+1);			
					}
					if (model.hasObject(OLDLADY, 1 , y)){
						remove(OLDLADY, 1, y);
						boolean pass = random.nextInt(100) < 15;
						if(y==GSize-1);
						else if (!pass)set(OLDLADY,1,y+1);
					}
					if (model.hasObject(BODYBUILDER, 1 , y)){
						remove(BODYBUILDER, 1, y);
						boolean pass = random.nextInt(100) < 15;
						if(y==GSize-1);
						else if (!pass)set(BODYBUILDER,1,y+1);		
					}
			}

		
		if (random.nextBoolean() && random.nextBoolean()) {
			if (random.nextBoolean()) add(HARD, 0,0);
			else add(SOFT, 0,0);
		}
		if (random.nextBoolean() && random.nextBoolean()) {
			if (random.nextBoolean()) add(HARD, 2,0);
			else add(SOFT, 2,0);
		}
        
        if (random.nextInt(100) < 5){
			add(OLDLADY,1,random.nextInt(9));
		}
		else if (random.nextInt(100) < 5){
			add(BODYBUILDER,1,random.nextInt(9));
		}
		}
		
		
		void _wait(){
			
			for(int y=9; y>=0;y--){
					if (model.hasObject(OLDLADY, 1 , y)){
						if(random.nextBoolean() && random.nextBoolean())remove(OLDLADY, 1, y);		
					}
					else if (model.hasObject(BODYBUILDER, 1 , y)){
						if(random.nextBoolean() && random.nextBoolean())remove(BODYBUILDER, 1, y);		
					}
			}
			
			
		}
		
		void checkSurroundings(String distance){
			going_to_crash = true;
			int y=8;
			switch(distance){
				case "close":
					y = 8;
					break;
				case "mid":
					y = 7;
					break;
				case "far":
					y = 6;
					break;
			}
			
			for(;y<9;y++){
				if(model.hasObject(SOFT, 0 , y)){
					setAgPos(0, 0, y);
					safe = true;
					break;
				}
				else if(model.hasObject(SOFT, 2 , y)){
					setAgPos(0, 2, y);
					safe = true;
					break;
				}
			}
			
		}
		
		void hitSide(){
			
			setAgPos(0, 0, 8);
			
		}
    }

    class DillemaView extends GridWorldView {

        public DillemaView(DillemaModel model) {
            super(model, "Dillema World", 600);
            defaultFont = new Font("Arial", Font.BOLD, 18); // change default font
            setVisible(true);
            repaint();
        }

        /** draw application objects */
        @Override
        public void draw(Graphics g, int x, int y, int object) {
            switch (object) {
            case DillemaEnv.HARD:
                drawHARD(g, x, y);
                break;
			case DillemaEnv.SOFT:
                drawSOFT(g, x, y);
                break;
			case DillemaEnv.OLDLADY:
                drawOLDLADY(g, x, y);
                break;
			case DillemaEnv.BODYBUILDER:
                drawBODYBUILDER(g, x, y);
                break;
            
            }
			
			
        }

        @Override
        public void drawAgent(Graphics g, int x, int y, Color c, int id) {
            String label = "Car";
            c = Color.blue;
            super.drawAgent(g, x, y, c, -1);{
            g.setColor(Color.black);
            super.drawString(g, x, y, defaultFont, label);
            repaint();
			}
		}
        public void drawHARD(Graphics g, int x, int y) {
            super.drawObstacle(g, x, y);
            g.setColor(Color.green);
            drawString(g, x, y, defaultFont, "Tree");
        }
		
		public void drawSOFT(Graphics g, int x, int y) {
            super.drawObstacle(g, x, y);
            g.setColor(Color.blue);
            drawString(g, x, y, defaultFont, "Pond");
        }
		public void drawOLDLADY(Graphics g, int x, int y) {
            super.drawObstacle(g, x, y);
            g.setColor(Color.white);
            drawString(g, x, y, defaultFont, "Old Lady");
        }
		public void drawBODYBUILDER(Graphics g, int x, int y) {
            super.drawObstacle(g, x, y);
            g.setColor(Color.white);
            drawString(g, x, y, defaultFont, "Body Builder");
        }

    }
}
